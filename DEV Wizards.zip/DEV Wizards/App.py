from flask import Flask, render_template

app = Flask(__name__, template_folder="template", static_folder="static")


@app.route("/")
def index():
    return render_template("Home.html")

@app.route("/Home")
def home():
    return render_template("Home.html")


@app.route("/About")
def about():
    return render_template("About.html")


@app.route("/Contacts")
def contacts():
    return render_template("Contacts.html")


@app.route("/login")
def login():
    return render_template("Login.html")


@app.route("/Cart")
def cart():
    return render_template("Cart.html")


@app.route("/What_we_do")
def wwd():
    return render_template("wwd.html")


@app.route("/How_we_do")
def hwd():
    return render_template("hwd.html")


@app.route("/moto")
def moto():
    return render_template("moto.html")


app.run(debug=True)
